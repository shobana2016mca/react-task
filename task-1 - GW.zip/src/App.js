import React from "react";
import Form from "./pages/forms/createjob-step1";
import ".//App.css";
import CardData from "./pages/card/card-data";

const App = () => {
  return (
    <>
      {/* <Form /> */}
      <CardData />
    </>
  );
};

export default App;
